int sum1(int a[])
{
    a[1] = a[0] + a[1];
    return a[1];
}

int sum2(int a[][3], int row)
{
    a[row][2] = a[row][0] + a[row][1];
    return a[row][2];
}

int main()
{
    int x[3];
    int y[2][3];

    x[0] = 4;
    x[1] = 5;

    y[1][0] = 7;
    y[1][1] = 8;

    return sum1(x) + sum2(y, 1);
}
