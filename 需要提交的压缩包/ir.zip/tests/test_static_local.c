int f() {
    static int a = 3;
    a = a + 1;
    return a;
}

int main() {
    putint(f());
    putint(f());
    return 0;
}
