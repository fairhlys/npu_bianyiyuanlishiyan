int main() {
    int s = 0;
    for (int i = 0; i < 5; i++) {
        s = s + i;
    }

    int j = 3;
    for (; j > 0; --j) {
        s = s + 1;
    }

    for (;;) {
        s = s + 100;
        break;
    }

    putint(s);
    return 0;
}
