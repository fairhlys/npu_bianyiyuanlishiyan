static int g = 7;
int main() {
    putint(g);
    g = g + 2;
    putint(g);
    return 0;
}
