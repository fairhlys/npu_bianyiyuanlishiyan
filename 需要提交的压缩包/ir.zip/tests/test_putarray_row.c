int first(int a[])
{
    return a[0];
}

int main()
{
    int a[2][3];
    a[1][0] = 1;
    a[1][1] = 2;
    a[1][2] = 3;
    return first(a[1]);
}
