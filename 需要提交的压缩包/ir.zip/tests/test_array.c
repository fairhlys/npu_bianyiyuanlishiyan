int main()
{
    int arr[10];
    int i;
    i = 0;
    arr[i] = 5;
    return arr[i];
}
