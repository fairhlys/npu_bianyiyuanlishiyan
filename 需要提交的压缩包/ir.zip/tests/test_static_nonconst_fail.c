int main() {
    int x = 1;
    static int a = x;
    putint(a);
    return 0;
}
